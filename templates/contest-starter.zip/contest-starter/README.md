# 复制这个目录，开始一个比赛项目

**第一次用：先跑[填好的3分钟练习](../contest-starter-example/README.md)。** 它只用Python标准库，输入、结果和预期数字都已给出；不用模型、账号或密钥。

把本目录复制到独立工作区，不要在指南仓库里放真实参赛数据或个人信息。无需安装新skill；这是给现有coding agent读取的文件模板。

## 最少先给这三件东西

1. 你要做什么：写一段真实需求，或者像练习样例那样明确标为自拟练习。
2. 可以用的输入：完整附件或获准数据；没有真实数据时先用显式标注的合成数据调试。
3. 第一版怎样算完成：至少一个输入、一个处理动作、一个能核对的输出。

练习可以先做这三项。正式赛在继续生成核心材料前，必须补齐当届规则、资格和工具范围；不确定就写待核，不用把项目卡18个字段一次填成漂亮答案。

## 工作区放什么

建议目录：

~~~text
inputs/           当届规则、评分表、本校认定、题面与需求
data/raw/        获准使用的原始数据
data/processed/  脚本生成的清洗数据
code/            可复跑实现
results/         真实结果
docs/            决策、说明、证据与答辩
run-logs/        本次运行与失败记录
~~~

1. 先填 [PROJECT_BRIEF.md](PROJECT_BRIEF.md)，未知就写待核。
2. 数据填 [data-provenance.csv](data-provenance.csv)，评分与实际证据填 [score-evidence.csv](score-evidence.csv)。空表不是已完成的检查。
3. 把 [START_PROMPT.txt](START_PROMPT.txt) 发给Codex/Claude Code。先跑最小闭环，之后再补模型、功能与展示。

第一步的完成标志：在 `results/` 打开一份真实结果或可运行界面，能从输入重跑得到它，并说清一个已知限制。PPT和获奖目标不作为第一步验收。

这是非数模通用模板，不替代专用软件、比赛资格或工具许可。数模从[完整技能链教程](https://github.com/Rain-dust/HowToCompeteBetter/blob/main/docs/coding-agent.md)开始。
